
# Step 1. Subir la base de datos de dengue de la semana pasada #####
y <- denhotspots::read_dengue_dataset(path = "1.Datasets/semana_actual/DENGUE2_.txt",
                                      spatial_resolution = "municipality",
                                      des_edo_res = "SONORA",
                                      des_mpo_res = "HERMOSILLO") 

head(y)

?denhotspots::read_dengue_dataset
# Step 2. Subir la base de datos de la semana actual ####
x  <- denhotspots::read_dengue_dataset() 


# Step 3. extract the ids not geocoded ###
z <- x |>
    dplyr::filter(!VEC_ID %in% c(y$VEC_ID)) |>
    dplyr::arrange(VEC_ID)


# Step 3. save the results ####
write.csv(y, file = "positive_denmx_2022_11_10.csv")

